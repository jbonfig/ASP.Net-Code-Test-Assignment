﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using CodeTestProject.Models;

namespace CodeTestProject.Migrations
{
    public class CodeTestInitializer : DropCreateDatabaseAlways<CodeTestContext>
    {
        protected override void Seed(CodeTestContext context)
        {
            context.Customers.Add(new Customer { Id = 1, Code = 111, Description = "Customer1" });
            context.Customers.Add(new Customer { Id = 2, Code = 222, Description = "Customer2" });
            context.Customers.Add(new Customer { Id = 3, Code = 333, Description = "Customer3" });

            context.Addresses.Add(new Address { Id = 1, Addr = "1001 1st St.", City = "City1", State = "IL", ZipCode = 60540 });
            context.Addresses.Add(new Address { Id = 2, Addr = "2001 2nd St.", City = "City2", State = "IL", ZipCode = 60540 });
            context.Addresses.Add(new Address { Id = 3, Addr = "3001 3rd St.", City = "City3", State = "IL", ZipCode = 60542 });
            context.Addresses.Add(new Address { Id = 4, Addr = "4001 4th St.", City = "City4", State = "IL", ZipCode = 60543 });
            context.Addresses.Add(new Address { Id = 5, Addr = "5001 5th St.", City = "City5", State = "IL", ZipCode = 60555 });

            context.CustomerAddresses.Add(new CustomerAddress { Id = 1, CustomerID = 1, AddressID = 1 });
            context.CustomerAddresses.Add(new CustomerAddress { Id = 2, CustomerID = 1, AddressID = 3 });
            context.CustomerAddresses.Add(new CustomerAddress { Id = 3, CustomerID = 1, AddressID = 5 });
            context.CustomerAddresses.Add(new CustomerAddress { Id = 4, CustomerID = 2, AddressID = 2 });
            context.CustomerAddresses.Add(new CustomerAddress { Id = 5, CustomerID = 2, AddressID = 4 });
            context.CustomerAddresses.Add(new CustomerAddress { Id = 6, CustomerID = 3, AddressID = 1 });
            context.CustomerAddresses.Add(new CustomerAddress { Id = 7, CustomerID = 3, AddressID = 2 });
            context.CustomerAddresses.Add(new CustomerAddress { Id = 8, CustomerID = 3, AddressID = 3 });
            context.CustomerAddresses.Add(new CustomerAddress { Id = 9, CustomerID = 3, AddressID = 4 });
            context.CustomerAddresses.Add(new CustomerAddress { Id = 10, CustomerID = 3, AddressID = 5 });

            context.SaveChanges();
        }
    }
}