﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;
using Microsoft.Extensions.DependencyInjection;
using CodeTestProject.Interfaces;
using CodeTestProject.Services;
using CodeTestProject.Models;

namespace CodeTestProject.Controllers
{
    public class CustomerController : Controller
    {
        // GET: Customer

        private IGetService _service;

        public CustomerController(IGetService service)
        {
            _service = service;
        }

        public JsonResult Index()
        {
            var results = _service.Get().ToList();

            return Json(new { results }, JsonRequestBehavior.AllowGet);
        }
    }
}
