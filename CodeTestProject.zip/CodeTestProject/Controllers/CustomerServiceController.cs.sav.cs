﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;
using CodeTestProject.Interfaces;
using CodeTestProject.Models;

namespace CodeTestProject.Controllers
{
//    public class CustomerServiceController : ApiController
    public class CustomerServiceController : Controller
    {
        // GET api/customerservice

        private IGetContext _getContext;

        public CustomerServiceController()
        {
        }

        public CustomerServiceController(IGetContext getContext)
            : base()
        {
            _getContext = getContext;
        }

        CodeTestContext _context = new CodeTestContext();   // Delete for DI

        public CodeTestContext context
        {
            get { return _context; }                        // Comment or Delete for DI
            // get { return _getContext.context; }          // Un-Comment for DI
        }

        [HttpGet]
        public HttpWebResponse Get()
        {
            var results = context.CustomerAddresses
                  .Include(d => d.Customer)
                  .Include(d => d.Address)
                  .Select(d => new CustomerDTO()
                  {
                      Customer = d.Customer.Description,
                      Address = d.Address.Addr,
                      City = d.Address.City,
                      State = d.Address.State,
                      ZipCode = d.Address.ZipCode
                  });

            return results;
        }
/*
        public HttpWebResponse RunIt()
        {
            var url = "http://localhost:49259/api/customerservice";

            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            request.Method = "GET";

            HttpWebResponse response = (HttpWebResponse)request.GetResponse();

            return response;
        }
*/
    }
}
