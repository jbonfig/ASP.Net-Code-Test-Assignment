﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using CodeTestProject.Interfaces;
using CodeTestProject.Models;

namespace CodeTestProject.Services
{
    public class GetContext : IGetContext
    {
        private CodeTestContext Context = new CodeTestContext();

        public CodeTestContext getContext()
        {
            return Context;
        }
    }
}