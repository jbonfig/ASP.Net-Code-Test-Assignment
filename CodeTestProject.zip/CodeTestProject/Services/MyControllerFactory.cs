﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using System.Web.SessionState;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using CodeTestProject.Interfaces;
using CodeTestProject.Controllers;
using CodeTestProject.Models;
using CodeTestProject.Services;

namespace CodeTestProject
{
    public class MyControllerFactory : IControllerFactory
    {
        public CustomerController myController;

        public MyControllerFactory()
        {
        }

        public IController CreateController(System.Web.Routing.RequestContext requestContext, string controllerName)
        {
            IGetContext context = new GetContext();
            IGetService service = new CustomerService(context);

            myController = new CustomerController(service);

            return (IController)myController;
        }

        public SessionStateBehavior GetControllerSessionBehavior(System.Web.Routing.RequestContext requestContext, string controllerName)
        {
            return SessionStateBehavior.Default;
        }

        public void ReleaseController(IController controller)
        {
            var disposable = controller as IDisposable;
            if (disposable != null)
            {
                disposable.Dispose();
            }
        }
    }
}