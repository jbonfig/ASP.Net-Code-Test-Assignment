﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Data.Sql;
using System.Web;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.DependencyInjection;
using CodeTestProject.Interfaces;
using CodeTestProject.Models;

namespace CodeTestProject.Services
{
    public class CustomerService : IGetService
    {
        private CodeTestContext Context;

        public CustomerService(IGetContext getContext)
        {
            Context = getContext.getContext();
        }

        //        CodeTestContext Context = new CodeTestContext();

        public IEnumerable<CustomerDTO> GetData()
        {
            IEnumerable<CustomerDTO> results = Context.CustomerAddresses
                                      .Include(d => d.Customer)
                                      .Include(d => d.Address)
                                      .OrderBy(d => d.Customer.Description)
                                      .Select(d => new CustomerDTO()
                                      {
                                          Customer = d.Customer.Description,
                                          Address = d.Address.Addr,
                                          City = d.Address.City,
                                          State = d.Address.State,
                                          ZipCode = d.Address.ZipCode
                                      });

            return results;
        }
    }
}