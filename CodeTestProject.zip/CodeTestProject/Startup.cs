﻿using System;
using System.Threading.Tasks;
using System.Web.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Owin;
using Owin;
using CodeTestProject.Interfaces;
using CodeTestProject.Models;
using CodeTestProject.Services;

[assembly: OwinStartup(typeof(CodeTestProject.Startup))]

namespace CodeTestProject
{
    public class Startup
    {
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddTransient<IGetService, CustomerService>();
            services.AddTransient<IGetContext, GetContext>();
            services.AddMvc();
        }

        public void Configuration(IAppBuilder app)
        {
            // For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=316888
        }
    }
}
