﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using Microsoft.EntityFrameworkCore.SqlServer;
using System.Data.Entity.ModelConfiguration.Conventions;
using Microsoft.Extensions.DependencyInjection;
using CodeTestProject.Interfaces;
using CodeTestProject.Models;

namespace CodeTestProject.Models
{
    public class CodeTestContext : DbContext
    {
        public DbSet<Customer> Customers { get; set; }
        public DbSet<Address> Addresses { get; set; }
        public DbSet<CustomerAddress> CustomerAddresses { get; set; }

        protected override void OnModelCreating(System.Data.Entity.DbModelBuilder modelBuilder)
        {
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();
            //            base.OnModelCreating(modelBuilder);
        }
        
    }
}