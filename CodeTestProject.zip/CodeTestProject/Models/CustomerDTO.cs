﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CodeTestProject.Models
{
    public class CustomerDTO
    {
        public string Customer { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public int ZipCode { get; set; }
    }
}