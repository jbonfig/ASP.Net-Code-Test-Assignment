﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CodeTestProject.Models;

namespace CodeTestProject.Interfaces
{
    public interface IGetContext
    {
        CodeTestContext getContext();
    }
}
